# Platforma: Telegram bot + Mini App

Bot (aiogram) + Mini App (FastAPI + HTML) + SQLite. Bitta `python bot.py` hammasini ishga tushiradi.

## O'rnatish
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env     # BOT_TOKEN, ADMIN_IDS, WEBAPP_URL, APP_SECRET ni to'ldiring
python bot.py
```
`WEBAPP_URL` — HTTPS manzil (Render yoki ngrok/cloudflared). Mini App fayllari (`webapp/`) shu manzilning o'zidan beriladi.

## Mini App sahifalari
Bosh (balans, boshlash tugmasi) · Bonus (taklif havolasi, do'stlar) · Yechish (Uzcard/Humo, 16 xonali karta) · Tarix.

## Admin buyruqlari (faqat ADMIN_IDS)
- `/settings` — sozlamalar
- `/setbonus 0.1` — har bir do'st uchun bonus ($)
- `/setmin 1` — minimal yechib olish ($)
- `/setwatch 0.5` — tomosha uchun soatiga ($); 0 = tomosha uchun to'lanmaydi
- `/withdrawals`, `/paid ID`, `/reject ID` — yechish so'rovlari (rad etilsa pul qaytadi)
- `/addvideo Sarlavha | https://youtu.be/ID`, `/videos`, `/delvideo ID`
- `/stats`

## Muhim
- Yechish so'rovi avtomatik to'lanmaydi: admin kartaga o'zi o'tkazadi va `/paid ID` bosadi.
- Karta raqamlari bazada saqlanadi (`data/platform.db`). Bazani va zaxira nusxalarini himoyalang.
- Render'da fayl tizimi vaqtinchalik bo'lishi mumkin: `DATABASE_PATH` ni doimiy diskka (Persistent Disk) qo'ying, aks holda qayta ishga tushganda baza o'chadi.
- Foydalanuvchilarga faqat siz haqiqatan to'laydigan narsani va'da qiling.
