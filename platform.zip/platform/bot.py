import asyncio

import uvicorn
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from api.routes import router as api_router
from config import BOT_TOKEN, PORT, WEBAPP_DIR
from database import init_db, set_setting
from handlers.admin import router as admin_router
from handlers.start import router as start_router

app = FastAPI(title="Platform API", docs_url=None, redoc_url=None)
app.include_router(api_router)
# Mini App fayllari (index.html, app.js, style.css). Eng oxirida ulanadi, shunda /api yo'llari bosilmaydi.
app.mount("/", StaticFiles(directory=str(WEBAPP_DIR), html=True), name="webapp")


async def run_api():
    server = uvicorn.Server(uvicorn.Config(app, host="0.0.0.0", port=PORT, log_level="info"))
    await server.serve()


async def run_bot():
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    me = await bot.get_me()
    await set_setting("bot_username", me.username or "")
    dp = Dispatcher()
    dp.include_router(start_router)
    dp.include_router(admin_router)
    await dp.start_polling(bot)


async def main():
    await init_db()
    await asyncio.gather(run_api(), run_bot())


if __name__ == "__main__":
    asyncio.run(main())
