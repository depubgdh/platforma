const tg = window.Telegram && window.Telegram.WebApp;
try { tg && (tg.ready(), tg.expand(), tg.setHeaderColor && tg.setHeaderColor("#16222b"), tg.setBackgroundColor && tg.setBackgroundColor("#0b1519")); } catch (e) {}
const initData = (tg && tg.initData) || "";
const $ = id => document.getElementById(id);
const MONTHS = ["yan", "fev", "mar", "apr", "may", "iyn", "iyl", "avg", "sen", "okt", "noy", "dek"];
const ICONS = {
  gift: '<svg viewBox="0 0 24 24"><rect x="3.5" y="8" width="17" height="4" rx="1"/><path d="M5 12v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7M12 8v12M12 8c-2.5 0-4-1-4-2.5S9 3 10.5 3.5 12 6 12 8zm0 0c2.5 0 4-1 4-2.5S15 3 13.5 3.5 12 6 12 8z"/></svg>',
  watch: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M10 8.5v7l5.5-3.5z"/></svg>',
  out: '<svg viewBox="0 0 24 24"><path d="M4 7a2 2 0 0 1 2-2h11v3"/><rect x="3" y="7" width="18" height="13" rx="3"/><circle cx="16.5" cy="13.5" r="1.2"/></svg>',
};
const STATUS = { ok: "Tasdiqlangan", paid: "To'langan", pending: "Kutilmoqda", rejected: "Rad etildi" };

let S = null, filter = "all", player = null, pingTimer = null, ytPromise = null, toastTimer = null;

/* ---------- yordamchilar ---------- */
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
function money(n) { n = Number(n) || 0; return (n > 0 && n < 0.01 ? n.toFixed(4) : n.toFixed(2)) + "$"; }
function signed(n) { n = Number(n) || 0; return (n >= 0 ? "+" : "−") + money(Math.abs(n)); }
function dur(sec) {
  sec = Math.floor(Number(sec) || 0);
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  return h ? `${h}h ${m}m` : m ? `${m}m` : `${s}s`;
}
function when(str) {
  const d = new Date(String(str).replace(" ", "T") + "Z");
  if (isNaN(d)) return String(str || "");
  const p = n => String(n).padStart(2, "0");
  return `${d.getDate()}-${MONTHS[d.getMonth()]} · ${p(d.getHours())}:${p(d.getMinutes())}`;
}
function toast(msg) {
  const t = $("toast"); t.textContent = msg; t.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 2800);
}
async function api(path, method = "GET", body = null) {
  const r = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json", "X-Telegram-Init-Data": initData },
    body: body ? JSON.stringify(body) : undefined,
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) {
    const det = d.detail;
    throw new Error(typeof det === "string" ? det : Array.isArray(det) ? "Ma'lumot noto'g'ri kiritildi" : "Xatolik yuz berdi");
  }
  return d;
}
function setBig(intId, decId, n) {
  const [i, d] = (Number(n) || 0).toFixed(2).split(".");
  $(intId).textContent = i; $(decId).textContent = "." + d;
}
function formatCard(v) { return v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})(?=.)/g, "$1 "); }
function cardKind(c) { return /^(8600|5614)/.test(c) ? "Uzcard" : /^9860/.test(c) ? "Humo" : "Karta"; }
function refLink() { return S && S.bot_username ? `https://t.me/${S.bot_username}?start=ref_${S.user.id}` : ""; }

/* ---------- sahifalar ---------- */
function show(tab) {
  document.querySelectorAll(".page").forEach(p => p.hidden = p.id !== "page-" + tab);
  document.querySelectorAll("#nav button").forEach(b => b.classList.toggle("on", b.dataset.tab === tab));
  window.scrollTo(0, 0);
}
document.querySelectorAll("#nav button").forEach(b => b.onclick = () => show(b.dataset.tab));
$("goInvite").onclick = () => show("bonus");

function renderSpark() {
  const svg = $("spark");
  const ev = (S.history || []).filter(h => h.status !== "rejected").slice().reverse();
  let run = 0; const pts = [0];
  ev.forEach(h => { run += Number(h.amount) || 0; pts.push(run); });
  if (pts.length < 2) pts.push(0);
  const min = Math.min(...pts), max = Math.max(...pts), span = max - min || 1;
  const xy = pts.map((v, i) => [i / (pts.length - 1) * 300, 60 - (v - min) / span * 50]);
  const line = xy.map((p, i) => (i ? "L" : "M") + p[0].toFixed(1) + " " + p[1].toFixed(1)).join(" ");
  svg.innerHTML = `<defs><linearGradient id="sg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#38e1c0" stop-opacity=".35"/><stop offset="1" stop-color="#38e1c0" stop-opacity="0"/></linearGradient></defs>
    <path d="${line} L300 70 L0 70 Z" fill="url(#sg)"/><path d="${line}" fill="none" stroke="#38e1c0" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>`;
}

function renderStats() {
  const u = S.user;
  setBig("balInt", "balDec", u.balance); setBig("wdInt", "wdDec", u.balance);
  $("chipToday").textContent = signed(u.today_income) + " bugun";
  $("todayChip").textContent = signed(u.balance);
  $("stToday").textContent = dur(u.today_seconds);
  $("stTotal").textContent = dur(u.total_seconds);
  $("stIncome").textContent = signed(u.total_income);
  $("mToday").textContent = dur(u.today_seconds);
  $("mIncome").textContent = signed(u.today_income);
  renderWithdrawBar();
}

function renderHome() {
  const u = S.user, n = S.referrals.count, bonus = S.settings.referral_bonus;
  $("avatar").textContent = (u.name || u.username || "?").trim().charAt(0).toUpperCase() || "?";
  $("uname").textContent = u.username ? "@" + u.username : (u.name || "Foydalanuvchi");
  $("uid").textContent = "ID " + u.id;
  $("chipFriends").textContent = "Do'stlar: " + n;
  $("slots").innerHTML = Array.from({ length: 6 }, (_, i) =>
    i < n ? `<div class="slot on">${esc((S.referrals.list[n - 1 - i] || S.referrals.list[i] || { name: "?" }).name.charAt(0).toUpperCase())}</div>` : `<div class="slot">+</div>`).join("");
  $("slotsText").textContent = n + " ta do'st taklif qilingan";
  $("slotsBonus").textContent = "+" + money(bonus) + " / do'st";
  $("startSub").textContent = S.video
    ? (S.settings.watch_rate > 0 ? `Tasdiqlangan tomosha: soatiga ${money(S.settings.watch_rate)}` : "Videoni ko'rish uchun bosing")
    : "Hozircha video yo'q";
  renderStats(); renderSpark();
}

function renderBonus() {
  const r = S.referrals, bonus = S.settings.referral_bonus, link = refLink();
  $("bnCount").textContent = r.count;
  $("bnTotal").textContent = money(r.total);
  $("refLink").textContent = link || "Havola tayyorlanmoqda… (bot birinchi marta ishga tushirilgach paydo bo'ladi)";
  $("bnNote").textContent = `Havolangiz orqali botga birinchi marta kirgan har bir yangi foydalanuvchi uchun ${money(bonus)} beriladi.`;
  $("bnPer").textContent = money(bonus);
  $("bnRate").textContent = S.settings.watch_rate > 0 ? money(S.settings.watch_rate) + "/soat" : "—";
  $("friendList").innerHTML = r.list.map(f =>
    `<div class="item"><div class="av">${esc((f.name || "?").charAt(0).toUpperCase())}</div>
     <div class="meta"><b>${esc(f.name)}</b><small>${when(f.created_at)}</small></div><span class="up">+${money(f.bonus)}</span></div>`).join("");
}

function renderWithdrawBar() {
  const bal = Number(S.user.balance) || 0, min = Number(S.settings.min_withdraw) || 0;
  const pct = min > 0 ? Math.min(100, bal / min * 100) : 100;
  $("wdBar").style.width = pct + "%";
  $("wdMin").textContent = bal >= min ? `Minimal: ${money(min)} · yechib olish mumkin` : `Minimal: ${money(min)} · yana ${money(min - bal)} kerak`;
}

function renderWithdraw() {
  renderWithdrawBar();
  const card = S.user.card;
  if (card && !$("cardIn").dataset.touched) $("cardIn").value = formatCard(card);
  updateCardHint();
  $("wdList").innerHTML = S.withdrawals.length ? S.withdrawals.map(w =>
    `<div class="item"><div class="meta"><b>#${w.id} · ${money(w.amount)}</b><small>•••• ${esc(w.card_tail)} · ${when(w.created_at)}</small></div>
     <span class="status ${w.status}">${STATUS[w.status] || w.status}</span></div>`).join("") : "";
}

function updateCardHint() {
  const digits = $("cardIn").value.replace(/\D/g, "");
  const pill = $("cardPill");
  if (digits.length >= 4) { pill.hidden = false; pill.textContent = cardKind(digits); } else pill.hidden = true;
  $("cardHint").textContent = digits.length === 16 ? (S && S.user.card === digits ? "Saqlangan karta" : "Karta raqami yechishda saqlanadi") : `${digits.length}/16`;
}

function renderHistory() {
  const items = (S.history || []).filter(h => filter === "all" || (filter === "withdrawal" ? h.type === "withdrawal" : h.type !== "withdrawal"));
  $("histList").innerHTML = items.length ? items.map(h => {
    const cls = h.type === "referral" ? "gift" : h.type === "watch" ? "watch" : h.type === "withdrawal" ? "out" : "gift";
    const ico = h.type === "withdrawal" ? ICONS.out : h.type === "watch" ? ICONS.watch : ICONS.gift;
    const sub = h.type === "watch" ? `${esc(h.sub)} · ${dur(h.seconds)}` : `${when(h.created_at)} · ${esc(h.sub)}`;
    return `<div class="h-item"><div class="h-ico ${cls}">${ico}</div>
      <div class="h-main"><b>${esc(h.title)}</b><small>${sub}</small></div>
      <div class="h-side"><span class="amt ${h.amount > 0 ? "pos" : ""}">${signed(h.amount)}</span>
      <span class="status ${h.status}">${STATUS[h.status] || h.status}</span></div></div>`;
  }).join("") : `<div class="empty">Hozircha yozuv yo'q</div>`;
}
$("filters").onclick = e => {
  const b = e.target.closest("button"); if (!b) return;
  filter = b.dataset.f;
  document.querySelectorAll("#filters button").forEach(x => x.classList.toggle("on", x === b));
  renderHistory();
};

function renderAll() { renderHome(); renderBonus(); renderWithdraw(); renderHistory(); }

async function load() {
  try { S = await api("/api/me"); renderAll(); }
  catch (e) { toast(e.message); $("uname").textContent = "Telegram orqali kiring"; }
}

/* ---------- bonus: nusxalash va ulashish ---------- */
$("copyBtn").onclick = async () => {
  const link = refLink(); if (!link) return toast("Havola hali tayyor emas");
  try { await navigator.clipboard.writeText(link); }
  catch (e) { const t = document.createElement("textarea"); t.value = link; document.body.appendChild(t); t.select(); try { document.execCommand("copy"); } catch (_) {} t.remove(); }
  toast("Havola nusxalandi");
};
$("shareBtn").onclick = () => {
  const link = refLink(); if (!link) return toast("Havola hali tayyor emas");
  const url = "https://t.me/share/url?url=" + encodeURIComponent(link) + "&text=" + encodeURIComponent("Men bilan birga qo'shiling!");
  if (tg && tg.openTelegramLink) tg.openTelegramLink(url); else window.open(url, "_blank");
};

/* ---------- yechib olish ---------- */
$("cardIn").oninput = e => { e.target.dataset.touched = "1"; e.target.value = formatCard(e.target.value); updateCardHint(); };
$("amtIn").oninput = e => { e.target.value = e.target.value.replace(",", ".").replace(/[^0-9.]/g, ""); };
$("allBtn").onclick = () => { $("amtIn").value = (Math.floor((Number(S.user.balance) || 0) * 100) / 100).toFixed(2); };
$("wdBtn").onclick = async () => {
  const card = $("cardIn").value.replace(/\D/g, ""), amount = parseFloat($("amtIn").value);
  if (card.length !== 16) return toast("Karta raqami 16 ta raqamdan iborat bo'lishi kerak");
  if (!(amount > 0)) return toast("Summani kiriting");
  const btn = $("wdBtn"); btn.disabled = true;
  try {
    await api("/api/withdraw", "POST", { amount, card });
    $("amtIn").value = ""; delete $("cardIn").dataset.touched;
    toast("So'rov yuborildi");
    await load();
  } catch (e) { toast(e.message); }
  btn.disabled = false;
};

/* ---------- video ---------- */
function loadYT() {
  if (window.YT && window.YT.Player) return Promise.resolve();
  if (!ytPromise) ytPromise = new Promise((res, rej) => {
    window.onYouTubeIframeAPIReady = res;
    const s = document.createElement("script"); s.src = "https://www.youtube.com/iframe_api";
    s.onerror = () => { ytPromise = null; rej(new Error("YouTube yuklanmadi")); };
    document.head.appendChild(s);
  });
  return ytPromise;
}
async function ping() {
  if (document.hidden) return;
  try {
    const d = await api("/api/watch/ping", "POST");
    Object.assign(S.user, d); renderStats(); $("chipFriends").textContent = "Do'stlar: " + S.referrals.count;
  } catch (e) { /* keyingi urinishda qayta */ }
}
function startPing() { if (pingTimer) return; ping(); pingTimer = setInterval(ping, 10000); $("startBtn").classList.add("live"); }
function stopPing() { clearInterval(pingTimer); pingTimer = null; $("startBtn").classList.remove("live"); }
function onState(e) {
  if (e.data === 1) startPing();
  else { stopPing(); if (e.data === 0) nextVideo(); }
}
function playVideo(v) {
  S.video = v; $("mTitle").textContent = v.title;
  if (player && player.loadVideoById) player.loadVideoById(v.youtube_id);
  else player = new YT.Player("ytbox", {
    host: "https://www.youtube-nocookie.com", videoId: v.youtube_id,
    playerVars: { autoplay: 1, rel: 0, playsinline: 1, modestbranding: 1 },
    events: { onReady: e => e.target.playVideo(), onStateChange: onState },
  });
}
async function nextVideo() {
  try { const d = await api("/api/video/next"); if (d.video) playVideo(d.video); else toast("Boshqa video yo'q"); }
  catch (e) { toast(e.message); }
}
$("startBtn").onclick = async () => {
  if (!S || !S.video) return toast("Hozircha video yo'q");
  $("modal").hidden = false;
  try { await loadYT(); playVideo(S.video); }
  catch (e) { toast(e.message); $("modal").hidden = true; }
};
$("mNext").onclick = nextVideo;
$("mClose").onclick = () => {
  stopPing(); $("modal").hidden = true;
  try { player && player.pauseVideo && player.pauseVideo(); } catch (e) {}
  load();
};

load();
