import os
import time
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

import aiosqlite

from config import DATABASE_PATH

TZ = timezone(timedelta(hours=5))  # Toshkent vaqti

# Admin shu qiymatlarni bot ichidan o'zgartiradi (/setbonus, /setmin, /setwatch)
DEFAULTS = {
    "referral_bonus": "0.1",   # har bir taklif qilingan do'st uchun, $
    "min_withdraw": "1",       # minimal yechib olish, $
    "watch_rate": "0",         # tasdiqlangan tomosha uchun soatiga $ (0 = tomosha uchun to'lanmaydi)
    "bot_username": "",
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
 telegram_id INTEGER PRIMARY KEY, username TEXT, first_name TEXT NOT NULL DEFAULT '',
 balance REAL NOT NULL DEFAULT 0, is_blocked INTEGER NOT NULL DEFAULT 0,
 referrer_id INTEGER, card TEXT, last_ping REAL NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS videos(
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, youtube_url TEXT NOT NULL,
 youtube_id TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS referrals(
 referred_id INTEGER PRIMARY KEY, referrer_id INTEGER NOT NULL, bonus REAL NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS transactions(
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL, amount REAL NOT NULL,
 kind TEXT NOT NULL, note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS watch_log(
 telegram_id INTEGER NOT NULL, day TEXT NOT NULL, seconds REAL NOT NULL DEFAULT 0,
 income REAL NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY(telegram_id, day)
);
CREATE TABLE IF NOT EXISTS withdrawals(
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id INTEGER NOT NULL, amount REAL NOT NULL,
 card TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, resolved_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(telegram_id, id);
CREATE INDEX IF NOT EXISTS idx_wd_user ON withdrawals(telegram_id, id);
CREATE INDEX IF NOT EXISTS idx_ref_referrer ON referrals(referrer_id);
"""

# Eski bazadan ko'chirish uchun (users jadvaliga yangi ustunlar)
MIGRATE_COLUMNS = (("referrer_id", "INTEGER"), ("card", "TEXT"), ("last_ping", "REAL NOT NULL DEFAULT 0"))


@asynccontextmanager
async def connect():
    os.makedirs(os.path.dirname(DATABASE_PATH) or ".", exist_ok=True)
    db = await aiosqlite.connect(DATABASE_PATH, isolation_level=None)
    db.row_factory = aiosqlite.Row
    try:
        await db.execute("PRAGMA foreign_keys=ON")
        await db.execute("PRAGMA busy_timeout=5000")
        yield db
    finally:
        await db.close()


@asynccontextmanager
async def transaction():
    """Bitta atomik tranzaksiya: xato bo'lsa hammasi bekor qilinadi."""
    async with connect() as db:
        await db.execute("BEGIN IMMEDIATE")
        try:
            yield db
        except BaseException:
            await db.execute("ROLLBACK")
            raise
        else:
            await db.execute("COMMIT")


async def init_db():
    async with connect() as db:
        await db.execute("PRAGMA journal_mode=WAL")
        await db.executescript(SCHEMA)
        cur = await db.execute("PRAGMA table_info(users)")
        have = {r["name"] for r in await cur.fetchall()}
        for name, decl in MIGRATE_COLUMNS:
            if name not in have:
                await db.execute(f"ALTER TABLE users ADD COLUMN {name} {decl}")


# ---------- yordamchilar ----------

def fnum(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def today():
    return datetime.now(TZ).strftime("%Y-%m-%d")


async def get_settings(db):
    cur = await db.execute("SELECT key,value FROM settings")
    data = dict(DEFAULTS)
    data.update({r["key"]: r["value"] for r in await cur.fetchall()})
    return data


async def set_setting(key, value):
    async with transaction() as db:
        await db.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )


async def _credit(db, tg_id, amount, kind, note=""):
    await db.execute("UPDATE users SET balance=ROUND(balance+?,6) WHERE telegram_id=?", (amount, tg_id))
    await db.execute(
        "INSERT INTO transactions(telegram_id,amount,kind,note) VALUES(?,?,?,?)",
        (tg_id, amount, kind, note),
    )


async def get_user(tg_id):
    async with connect() as db:
        cur = await db.execute("SELECT * FROM users WHERE telegram_id=?", (tg_id,))
        return await cur.fetchone()


# ---------- foydalanuvchi va taklif (referal) ----------

async def ensure_user(user, ref_id=None):
    """Foydalanuvchini yaratadi. Yangi bo'lsa va taklif havolasi orqali kelgan bo'lsa,
    taklif qilganga bonus beradi (har bir foydalanuvchi uchun faqat bir marta)."""
    result = {"new": False, "credited": False, "referrer": None, "bonus": 0.0}
    async with transaction() as db:
        cur = await db.execute("SELECT 1 FROM users WHERE telegram_id=?", (user.id,))
        exists = await cur.fetchone()
        await db.execute(
            """INSERT INTO users(telegram_id,username,first_name) VALUES(?,?,?)
               ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username,
               first_name=excluded.first_name,last_seen=CURRENT_TIMESTAMP""",
            (user.id, user.username, user.first_name or ""),
        )
        if exists:
            return result
        result["new"] = True
        if not ref_id or ref_id == user.id:
            return result
        cur = await db.execute("SELECT is_blocked FROM users WHERE telegram_id=?", (ref_id,))
        ref = await cur.fetchone()
        if not ref or ref["is_blocked"]:
            return result
        bonus = max(0.0, fnum((await get_settings(db))["referral_bonus"]))
        await db.execute("UPDATE users SET referrer_id=? WHERE telegram_id=?", (ref_id, user.id))
        await db.execute("INSERT INTO referrals(referred_id,referrer_id,bonus) VALUES(?,?,?)", (user.id, ref_id, bonus))
        if bonus > 0:
            name = user.first_name or (f"@{user.username}" if user.username else str(user.id))
            await _credit(db, ref_id, bonus, "referral", name)
        result.update(credited=bonus > 0, referrer=ref_id, bonus=bonus)
    return result


# ---------- tomosha ----------

async def watch_stats(db, tg_id):
    cur = await db.execute(
        "SELECT COALESCE(SUM(seconds),0) s, COALESCE(SUM(income),0) i FROM watch_log WHERE telegram_id=?", (tg_id,)
    )
    total = await cur.fetchone()
    cur = await db.execute(
        "SELECT seconds,income FROM watch_log WHERE telegram_id=? AND day=?", (tg_id, today())
    )
    day = await cur.fetchone()
    cur = await db.execute("SELECT balance FROM users WHERE telegram_id=?", (tg_id,))
    bal = await cur.fetchone()
    return {
        "balance": bal["balance"] if bal else 0,
        "today_seconds": day["seconds"] if day else 0,
        "today_income": day["income"] if day else 0,
        "total_seconds": total["s"],
        "total_income": total["i"],
    }


async def record_watch(tg_id, now=None):
    """Video o'ynab turganda mijoz har ~10 soniyada chaqiradi.
    Server o'z soatiga qaraydi: ketma-ket ikki chaqiruv orasidagi vaqt (ko'pi bilan 15 soniya) hisoblanadi.
    Bir nechta qurilmadan bir vaqtda chaqirilsa ham, jami vaqt real vaqtdan oshmaydi."""
    now = time.time() if now is None else now
    async with transaction() as db:
        cur = await db.execute("SELECT last_ping FROM users WHERE telegram_id=?", (tg_id,))
        row = await cur.fetchone()
        if not row:
            raise ValueError("Foydalanuvchi topilmadi")
        gap = now - float(row["last_ping"] or 0)
        delta = min(gap, 15.0) if 0 < gap <= 30 else 0.0
        await db.execute("UPDATE users SET last_ping=? WHERE telegram_id=?", (now, tg_id))
        if delta > 0:
            rate = max(0.0, fnum((await get_settings(db))["watch_rate"]))
            income = round(delta * rate / 3600, 6)
            await db.execute(
                """INSERT INTO watch_log(telegram_id,day,seconds,income) VALUES(?,?,?,?)
                   ON CONFLICT(telegram_id,day) DO UPDATE SET seconds=seconds+excluded.seconds,
                   income=ROUND(income+excluded.income,6),updated_at=CURRENT_TIMESTAMP""",
                (tg_id, today(), delta, income),
            )
            if income > 0:
                await db.execute(
                    "UPDATE users SET balance=ROUND(balance+?,6) WHERE telegram_id=?", (income, tg_id)
                )
        return await watch_stats(db, tg_id)


async def random_video():
    async with connect() as db:
        cur = await db.execute("SELECT id,title,youtube_id FROM videos WHERE active=1 ORDER BY RANDOM() LIMIT 1")
        row = await cur.fetchone()
        return dict(row) if row else None


# ---------- karta va yechib olish ----------

async def save_card(tg_id, card):
    async with transaction() as db:
        await db.execute("UPDATE users SET card=? WHERE telegram_id=?", (card, tg_id))


async def request_withdrawal(tg_id, amount, card):
    amount = round(float(amount), 2)
    async with transaction() as db:
        cur = await db.execute("SELECT balance,is_blocked FROM users WHERE telegram_id=?", (tg_id,))
        user = await cur.fetchone()
        if not user or user["is_blocked"]:
            raise ValueError("Hisob mavjud emas yoki bloklangan")
        minimum = fnum((await get_settings(db))["min_withdraw"])
        if amount < minimum:
            raise ValueError(f"Minimal yechib olish summasi {minimum:g}$")
        cur = await db.execute("SELECT 1 FROM withdrawals WHERE telegram_id=? AND status='pending'", (tg_id,))
        if await cur.fetchone():
            raise ValueError("Oldingi so'rovingiz hali ko'rib chiqilmoqda")
        if amount > round(float(user["balance"]), 2) + 1e-9:
            raise ValueError("Balans yetarli emas")
        await _credit(db, tg_id, -amount, "withdraw", "Yechib olish so'rovi")
        await db.execute("UPDATE users SET card=? WHERE telegram_id=?", (card, tg_id))
        cur = await db.execute("INSERT INTO withdrawals(telegram_id,amount,card) VALUES(?,?,?)", (tg_id, amount, card))
        cur2 = await db.execute("SELECT balance FROM users WHERE telegram_id=?", (tg_id,))
        return cur.lastrowid, (await cur2.fetchone())["balance"]


async def resolve_withdrawal(wid, approve):
    """Admin: to'landi (approve=True) yoki rad etildi (pul balansga qaytariladi)."""
    async with transaction() as db:
        cur = await db.execute("SELECT * FROM withdrawals WHERE id=?", (wid,))
        w = await cur.fetchone()
        if not w:
            raise ValueError("So'rov topilmadi")
        if w["status"] != "pending":
            raise ValueError("Bu so'rov allaqachon ko'rib chiqilgan")
        status = "paid" if approve else "rejected"
        await db.execute(
            "UPDATE withdrawals SET status=?,resolved_at=CURRENT_TIMESTAMP WHERE id=?", (status, wid)
        )
        if not approve:
            await _credit(db, w["telegram_id"], w["amount"], "refund", f"So'rov #{wid} rad etildi")
        return dict(w, status=status)


async def change_balance(tg_id, amount, kind, note):
    async with transaction() as db:
        cur = await db.execute("SELECT balance FROM users WHERE telegram_id=?", (tg_id,))
        row = await cur.fetchone()
        if not row:
            raise ValueError("Foydalanuvchi topilmadi")
        new_balance = round(float(row["balance"]) + float(amount), 6)
        if new_balance < 0:
            raise ValueError("Balans yetarli emas")
        await _credit(db, tg_id, amount, kind, note)
        return new_balance


# ---------- ilova uchun umumiy ma'lumot ----------

async def overview(tg_id):
    async with connect() as db:
        cur = await db.execute("SELECT * FROM users WHERE telegram_id=?", (tg_id,))
        user = await cur.fetchone()
        if not user:
            return None
        s = await get_settings(db)
        stats = await watch_stats(db, tg_id)

        cur = await db.execute(
            """SELECT r.created_at,r.bonus,u.first_name,u.username FROM referrals r
               LEFT JOIN users u ON u.telegram_id=r.referred_id
               WHERE r.referrer_id=? ORDER BY r.rowid DESC LIMIT 100""", (tg_id,))
        refs = [
            {"name": r["first_name"] or (f"@{r['username']}" if r["username"] else "Do'st"),
             "created_at": r["created_at"], "bonus": r["bonus"]}
            for r in await cur.fetchall()
        ]
        cur = await db.execute(
            "SELECT COUNT(*) n, COALESCE(SUM(bonus),0) b FROM referrals WHERE referrer_id=?", (tg_id,))
        rc = await cur.fetchone()

        cur = await db.execute("SELECT id,title,youtube_id FROM videos WHERE active=1 ORDER BY RANDOM() LIMIT 1")
        video = await cur.fetchone()

        history = []
        cur = await db.execute(
            """SELECT amount,kind,note,created_at FROM transactions
               WHERE telegram_id=? AND kind NOT IN('withdraw','refund') ORDER BY id DESC LIMIT 60""", (tg_id,))
        for r in await cur.fetchall():
            title = {"referral": "Do'st bonusi"}.get(r["kind"], "Admin tuzatishi")
            history.append({"type": "referral" if r["kind"] == "referral" else "adjust", "title": title,
                            "sub": r["note"], "amount": r["amount"], "status": "ok", "created_at": r["created_at"]})
        cur = await db.execute(
            "SELECT day,income,seconds,updated_at FROM watch_log WHERE telegram_id=? AND income>0 ORDER BY day DESC LIMIT 30",
            (tg_id,))
        for r in await cur.fetchall():
            history.append({"type": "watch", "title": "Tomosha", "sub": r["day"], "amount": r["income"],
                            "status": "ok", "created_at": r["updated_at"], "seconds": r["seconds"]})
        cur = await db.execute(
            "SELECT id,amount,card,status,created_at FROM withdrawals WHERE telegram_id=? ORDER BY id DESC LIMIT 30",
            (tg_id,))
        withdrawals = []
        for r in await cur.fetchall():
            item = {"id": r["id"], "amount": r["amount"], "card_tail": r["card"][-4:], "status": r["status"],
                    "created_at": r["created_at"]}
            withdrawals.append(item)
            history.append({"type": "withdrawal", "title": f"Yechib olish #{r['id']}", "sub": f"•••• {r['card'][-4:]}",
                            "amount": -r["amount"], "status": r["status"], "created_at": r["created_at"]})
        history.sort(key=lambda x: x["created_at"], reverse=True)

        return {
            "user": {"id": tg_id, "name": user["first_name"], "username": user["username"],
                     "card": user["card"], **stats},
            "settings": {"referral_bonus": fnum(s["referral_bonus"]), "min_withdraw": fnum(s["min_withdraw"]),
                         "watch_rate": fnum(s["watch_rate"])},
            "bot_username": s["bot_username"],
            "referrals": {"count": rc["n"], "total": rc["b"], "list": refs},
            "video": dict(video) if video else None,
            "history": history[:80],
            "withdrawals": withdrawals,
        }
