import re

PATTERN = re.compile(
    r"(?:youtube\.com/watch\?(?:[^#\s]*&)?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/shorts/)([A-Za-z0-9_-]{11})"
)


def parse_video_id(url):
    match = PATTERN.search((url or "").strip())
    if not match:
        raise ValueError("YouTube havolasi noto'g'ri")
    return match.group(1)
