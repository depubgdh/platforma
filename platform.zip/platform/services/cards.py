import re


def clean_card(value):
    """Bo'sh joy va chiziqlarni olib tashlaydi, 16 xonali raqamni qaytaradi."""
    digits = re.sub(r"[\s-]", "", str(value or ""))
    if not re.fullmatch(r"\d{16}", digits):
        raise ValueError("Karta raqami aniq 16 ta raqamdan iborat bo'lishi kerak")
    return digits


def card_type(card):
    if card.startswith(("8600", "5614")):
        return "Uzcard"
    if card.startswith("9860"):
        return "Humo"
    return "Karta"


def mask(card):
    return f"{card[:4]} {card[4:6]}** **** {card[12:]}"
