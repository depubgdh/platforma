from aiogram import Bot, F, Router
from aiogram.filters import CommandObject, CommandStart
from aiogram.types import (InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, Message,
                           ReplyKeyboardMarkup, WebAppInfo)

from config import WEBAPP_URL
from database import ensure_user

router = Router()


def open_app_markup():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🚀 Ilovani ochish", web_app=WebAppInfo(url=WEBAPP_URL))]
    ])


@router.message(CommandStart())
async def start(message: Message, command: CommandObject, bot: Bot):
    ref = None
    arg = (command.args or "").strip()
    if arg.startswith("ref_") and arg[4:].isdigit():
        ref = int(arg[4:])
    res = await ensure_user(message.from_user, ref)
    if res["credited"]:
        try:
            await bot.send_message(res["referrer"], f"🎉 Yangi do'st qo'shildi! Balansingizga +{res['bonus']:g}$ qo'shildi.")
        except Exception:
            pass
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🚀 Ilovani ochish", web_app=WebAppInfo(url=WEBAPP_URL))],
        [KeyboardButton(text="ℹ️ Yordam")],
    ], resize_keyboard=True)
    await message.answer("Assalomu alaykum! Ilovani ochish uchun pastdagi tugmani bosing.", reply_markup=kb)
    await message.answer("👇", reply_markup=open_app_markup())


@router.message(F.text == "ℹ️ Yordam")
async def help_msg(message: Message):
    await message.answer(
        "🚀 Ilovani oching.\n"
        "• Bosh sahifada video ko'ring.\n"
        "• Bonus bo'limidan do'stlarni taklif qiling.\n"
        "• Yechish bo'limida kartangizni kiriting va so'rov yuboring."
    )
