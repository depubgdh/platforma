from aiogram import Bot, Router
from aiogram.filters import Command
from aiogram.types import Message

import database as dbm
from config import ADMIN_IDS
from database import connect, fnum, get_settings, set_setting
from services.cards import card_type
from services.youtube import parse_video_id

router = Router()


def is_admin(m):
    return bool(m.from_user and m.from_user.id in ADMIN_IDS)


def arg(m):
    return (m.text or "").partition(" ")[2].strip()


@router.message(Command("admin"))
async def help_admin(m: Message):
    if not is_admin(m):
        return
    await m.answer(
        "🛠 ADMIN BUYRUQLARI\n\n"
        "<b>Sozlamalar</b>\n"
        "/settings — joriy sozlamalar\n"
        "/setbonus 0.1 — har bir do'st uchun bonus ($)\n"
        "/setmin 1 — minimal yechib olish ($)\n"
        "/setwatch 0.5 — tomosha uchun soatiga ($), 0 = to'lanmaydi\n\n"
        "<b>Yechib olish</b>\n"
        "/withdrawals — kutilayotgan so'rovlar\n"
        "/paid ID — to'langan deb belgilash\n"
        "/reject ID — rad etish (pul balansga qaytadi)\n\n"
        "<b>Videolar</b>\n"
        "/addvideo Sarlavha | https://youtu.be/VIDEO_ID\n/videos\n/delvideo ID\n\n"
        "/stats — umumiy statistika"
    )


@router.message(Command("settings"))
async def settings_cmd(m: Message):
    if not is_admin(m):
        return
    async with connect() as db:
        s = await get_settings(db)
    await m.answer(
        "⚙️ Sozlamalar\n"
        f"Do'st bonusi: {fnum(s['referral_bonus']):g}$\n"
        f"Minimal yechish: {fnum(s['min_withdraw']):g}$\n"
        f"Tomosha: {fnum(s['watch_rate']):g}$ / soat"
    )


async def _set_number(m, key, label, unit, lo, hi):
    if not is_admin(m):
        return
    try:
        value = float(arg(m).replace(",", "."))
        if not lo <= value <= hi:
            raise ValueError
    except ValueError:
        await m.answer(f"Foydalanish: raqam yozing ({lo:g} dan {hi:g} gacha). Masalan: /{key_cmd[key]} 0.1")
        return
    await set_setting(key, value)
    await m.answer(f"✅ {label}: {value:g}{unit}")


key_cmd = {"referral_bonus": "setbonus", "min_withdraw": "setmin", "watch_rate": "setwatch"}


@router.message(Command("setbonus"))
async def setbonus(m: Message):
    await _set_number(m, "referral_bonus", "Do'st bonusi", "$", 0, 1000)


@router.message(Command("setmin"))
async def setmin(m: Message):
    await _set_number(m, "min_withdraw", "Minimal yechish", "$", 0, 100000)


@router.message(Command("setwatch"))
async def setwatch(m: Message):
    await _set_number(m, "watch_rate", "Tomosha (soatiga)", "$", 0, 1000)


@router.message(Command("withdrawals"))
async def withdrawals(m: Message):
    if not is_admin(m):
        return
    async with connect() as db:
        cur = await db.execute(
            """SELECT w.id,w.telegram_id,w.amount,w.card,u.first_name,u.username FROM withdrawals w
               LEFT JOIN users u ON u.telegram_id=w.telegram_id WHERE w.status='pending' ORDER BY w.id""")
        rows = await cur.fetchall()
    if not rows:
        await m.answer("Kutilayotgan so'rov yo'q.")
        return
    await m.answer("\n\n".join(
        f"#{r['id']} · {r['amount']:g}$\n👤 {r['first_name'] or ''} {('@' + r['username']) if r['username'] else ''} (ID {r['telegram_id']})\n"
        f"💳 {card_type(r['card'])}: <code>{r['card']}</code>\n/paid {r['id']}  ·  /reject {r['id']}"
        for r in rows))


async def _resolve(m, bot, approve):
    if not is_admin(m):
        return
    try:
        w = await dbm.resolve_withdrawal(int(arg(m)), approve)
    except ValueError as e:
        await m.answer(f"Xato: {e}\nFoydalanish: /{'paid' if approve else 'reject'} ID")
        return
    await m.answer(f"✅ #{w['id']} {'to‘langan deb belgilandi' if approve else 'rad etildi, pul balansga qaytarildi'}.")
    text = (f"✅ Yechib olish so'rovingiz (#{w['id']}, {w['amount']:g}$) bajarildi. Karta: •••• {w['card'][-4:]}"
            if approve else
            f"❌ Yechib olish so'rovingiz (#{w['id']}, {w['amount']:g}$) rad etildi. Mablag' balansingizga qaytarildi.")
    try:
        await bot.send_message(w["telegram_id"], text)
    except Exception:
        pass


@router.message(Command("paid"))
async def paid(m: Message, bot: Bot):
    await _resolve(m, bot, True)


@router.message(Command("reject"))
async def reject(m: Message, bot: Bot):
    await _resolve(m, bot, False)


@router.message(Command("addvideo"))
async def addvideo(m: Message):
    if not is_admin(m):
        return
    try:
        title, url = [x.strip() for x in arg(m).split("|", 1)]
        vid = parse_video_id(url)
        if not title:
            raise ValueError("Sarlavha bo'sh")
        async with dbm.transaction() as db:
            await db.execute("INSERT INTO videos(title,youtube_url,youtube_id) VALUES(?,?,?)", (title, url, vid))
        await m.answer("✅ Video qo'shildi.")
    except Exception as e:
        await m.answer(f"Xato: {e}\nNamuna: /addvideo Sarlavha | https://youtu.be/VIDEO_ID")


@router.message(Command("videos"))
async def videos(m: Message):
    if not is_admin(m):
        return
    async with connect() as db:
        cur = await db.execute("SELECT id,title,active FROM videos ORDER BY id DESC")
        rows = await cur.fetchall()
    await m.answer("\n".join(f"{r['id']}. {r['title']} — {'faol' if r['active'] else 'nofaol'}" for r in rows) or "Video yo'q")


@router.message(Command("delvideo"))
async def delvideo(m: Message):
    if not is_admin(m):
        return
    try:
        i = int(arg(m))
        async with dbm.transaction() as db:
            await db.execute("DELETE FROM videos WHERE id=?", (i,))
        await m.answer("🗑 Video o'chirildi.")
    except Exception:
        await m.answer("Foydalanish: /delvideo ID")


@router.message(Command("stats"))
async def stats(m: Message):
    if not is_admin(m):
        return
    async with connect() as db:
        a = await (await db.execute("SELECT COUNT(*) n,COALESCE(SUM(balance),0) b FROM users")).fetchone()
        r = await (await db.execute("SELECT COUNT(*) n FROM referrals")).fetchone()
        v = await (await db.execute("SELECT COUNT(*) n FROM videos WHERE active=1")).fetchone()
        p = await (await db.execute(
            "SELECT COUNT(*) n,COALESCE(SUM(amount),0) s FROM withdrawals WHERE status='pending'")).fetchone()
        d = await (await db.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM withdrawals WHERE status='paid'")).fetchone()
    await m.answer(
        f"👥 Foydalanuvchilar: {a['n']}\n🤝 Takliflar: {r['n']}\n💰 Balanslar yig'indisi: {a['b']:.2f}$\n"
        f"🎬 Videolar: {v['n']}\n⏳ Kutilayotgan yechishlar: {p['n']} ta ({p['s']:.2f}$)\n✅ To'langan: {d['s']:.2f}$"
    )
