import secrets

from fastapi import APIRouter, Header, HTTPException
from pydantic import BaseModel, Field

import database as dbm
from config import APP_SECRET
from services.cards import clean_card
from services.security import verify_init_data

router = APIRouter(prefix="/api")


async def current_user(init_data):
    tg_id = verify_init_data(init_data)
    if not tg_id:
        raise HTTPException(401, "Telegram sessiyasi tasdiqlanmadi. Ilovani bot orqali oching.")
    user = await dbm.get_user(tg_id)
    if not user:
        raise HTTPException(403, "Avval botda /start bosing")
    if user["is_blocked"]:
        raise HTTPException(403, "Hisob bloklangan")
    return tg_id


@router.get("/me")
async def me(x_telegram_init_data: str | None = Header(default=None)):
    tg_id = await current_user(x_telegram_init_data)
    return await dbm.overview(tg_id)


@router.get("/video/next")
async def next_video(x_telegram_init_data: str | None = Header(default=None)):
    await current_user(x_telegram_init_data)
    return {"video": await dbm.random_video()}


@router.post("/watch/ping")
async def watch_ping(x_telegram_init_data: str | None = Header(default=None)):
    tg_id = await current_user(x_telegram_init_data)
    try:
        return await dbm.record_watch(tg_id)
    except ValueError as e:
        raise HTTPException(400, str(e))


class CardBody(BaseModel):
    card: str = Field(max_length=32)


@router.put("/card")
async def save_card(body: CardBody, x_telegram_init_data: str | None = Header(default=None)):
    tg_id = await current_user(x_telegram_init_data)
    try:
        card = clean_card(body.card)
    except ValueError as e:
        raise HTTPException(400, str(e))
    await dbm.save_card(tg_id, card)
    return {"ok": True}


class WithdrawBody(BaseModel):
    amount: float = Field(gt=0, le=100000)
    card: str = Field(max_length=32)


@router.post("/withdraw")
async def withdraw(body: WithdrawBody, x_telegram_init_data: str | None = Header(default=None)):
    tg_id = await current_user(x_telegram_init_data)
    try:
        card = clean_card(body.card)
        wid, balance = await dbm.request_withdrawal(tg_id, body.amount, card)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "id": wid, "balance": balance}


class Adjust(BaseModel):
    telegram_id: int
    amount: float = Field(gt=0, le=1000)
    note: str = Field(min_length=2, max_length=200)


@router.post("/admin/adjust")
async def admin_adjust(body: Adjust, x_admin_key: str | None = Header(default=None)):
    if not x_admin_key or not secrets.compare_digest(x_admin_key, APP_SECRET):
        raise HTTPException(403, "Admin ruxsati yo'q")
    try:
        balance = await dbm.change_balance(body.telegram_id, body.amount, "admin_adjust", body.note)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True, "balance": balance}
